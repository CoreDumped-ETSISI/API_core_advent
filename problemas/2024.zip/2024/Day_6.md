Secretos en la biblioteca

Los seres malignos de las neveras han encriptado libros de la biblioteca que los estudiantes necesitan para aprobar sus examenes. Sabemos que se pueden desencriptar con una simple clave, pero no sabemos cúal es. Nuestra única pista es una transmisión que hemos interceptado que contiene la siguiente imagen: 

Encuentra la clave en la transmisión.