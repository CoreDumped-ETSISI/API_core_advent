Aritmofobia

Un pobre CoreElfo se ha perdido en el departamento de MaTIC. Tiene un mapa con números, pero le da miedo ir a números inferiores al número en el que está. Ayúdale a encontrar el camino más corto que puede seguir para salir y llegar al CIC.

- Parte desde el 0 (Matic) y su destino es el 9 (CIC).
- Solo puede moverse a una casilla que tenga el mismo número o un número mayor por 1, de manera ortogonal.
- Encuentra la cantidad de movimientos que tiene que hacer para llegar a su destino en el menor número de pasos.

1111
0123
5554
6789 -> 11 pasos como mínimo (0-1-2-3-4-5-5-5-6-7-8-9)