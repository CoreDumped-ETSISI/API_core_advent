ADN cleptómano
¡Se acerca la navidad! 🎄🎅🏼🎁 CoreClaus ha dejado regalos en la rotonda, un ser de las Neveras que odia la diversión y ama las convocatorias extraordinarias, ha hecho de las suyas (los ha robado [es muy pillín]).

Nuestros investigadores han encontrado una serie de pistas que nos llevarán a la identidad del ladrón. La primera pista es la siguiente:

- Hemos encontrado un pelo colgado del árbol de Navidad. Lo hemos llevado a un laboratorio para descifrar su código genético y hemos obtenido la siguiente secuencia de nucleótidos: "". 

Tenemos un sospechoso que ha sido visto en la zona, con un poco de maña hemos conseguido obtener un trozo de su ADN. La secuencia de nucleótidos obtenida es la siguiente: "ACCTGA".


Encuentra la cantidad de veces que aparece esta secuencia en el ADN del pelo. 

Ejemplo:

"ACCTGACCTGA" -> 1
"ACACACA" -> 0
"TTACGACCTGAACCTGA" -> 2




