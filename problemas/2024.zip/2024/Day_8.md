Directorios


https://adventofcode.com/2023/day/12 # profundida total o directorio de un archivo