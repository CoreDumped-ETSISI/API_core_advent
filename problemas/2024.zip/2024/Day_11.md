gpt artificial

CoreGPT

CoreGrinch está harto de hacer tareas repetitivas, así que ha decidido crear un modelo de lenguaje que le ayude a hacerlas. CoreGPT sigue unas reglas muy sencillas para generar texto:








Devuelve la predicción número 'n' de CoreGPT tras introducirle el siguiente texto.






