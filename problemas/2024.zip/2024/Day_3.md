La mina de CoreCarbon

CoreClaus necesita carbón como regalo para los Telepes (todos sabemos que solo las personas extraordinarias van a convocatoria extraordinaria). Desgraciadamente, los CoreElfos han gastado todo el carbón en la barbacoa de la Fiesta de la Primavera. Toca ir a la mina a por más carbón.

La mina de CoreCarbon es un lugar muy peligroso, lleno de minas. Afortunadamente, los CoreElfos han encontrado un mapa de la mina que les ayudará a encontrar el camino más seguro. El mapa es una matriz de NxM, donde cada celda tiene un valor. Si los números adyacentes (ortogonal y diagonalmente) suman más de 42 significa que hay una mina en esa celda. Los CoreElfos quieren saber la suma de los valores de las celdas con minas.

Ejemplo:

```
[[5, 2, 3],
 [4, 5, 6],
 [7, 8, 9]] -> Hay minas y el valor es 5

[[1, 2, 3],
 [4, 5, 6],
 [7, 8, 9]] -> No hay mina
```